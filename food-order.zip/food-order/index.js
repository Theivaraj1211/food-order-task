const express = require('express');
const app = express();
const moment = require('moment');

// Set up a list of menu items and their prices
const menu = {
  burger: 8,
  fries: 4,
  shake: 5,
  salad: 7
};

// Set up the happy hour times and discounts
const happyHourTimes = [
  {
    day: 'Monday',
    start: '17:00',
    end: '19:00'
  },
  {
    day: 'Tuesday',
    start: '17:00',
    end: '19:00'
  },
  {
    day: 'Wednesday',
    start: '17:00',
    end: '19:00'
  },
  {
    day: 'Thursday',
    start: '17:00',
    end: '19:00'
  },
  {
    day: 'Friday',
    start: '17:00',
    end: '19:00'
  }
];
const happyHourDiscount = 0.5;

// Function to check if it is currently happy hour
function isHappyHour(time) {
  const day = moment(time).format('dddd');
  const hour = moment(time).format('HH:mm');
  for (let i = 0; i < happyHourTimes.length; i++) {
    if (happyHourTimes[i].day === day &&
        hour >= happyHourTimes[i].start &&
        hour < happyHourTimes[i].end) {
      return true;
    }
  }
  return false;
}

// Function to apply the happy hour discount to a price
function applyHappyHourDiscount(price) {
  return price * happyHourDiscount;
}

// Set up the /order endpoint
app.post('/order', (req, res) => {
  // Parse the request body to get the list of items and the time
  const items = req.body.items;
  const time = req.body.time;

  // Check if the time is valid
  if (!moment(time).isValid()) {
    return res.status(400).send({
      error: 'Invalid time'
    });
  }

  // Calculate the total price of the order
  let totalPrice = 0;
  for (let i = 0; i < items.length; i++) {
    const item = items[i];
    const price = menu[item];
    if (price === undefined) {
      return res.status(400).send({
        error: `Invalid item: ${item}`
      });
    }
    totalPrice += price;
  }

  // Check if it is currently happy hour and apply the discount if applicable
  if (isHappyHour(time)) {
    totalPrice = applyHappyHourDiscount(totalPrice);
  }

  // Return the total price to the client
  res.send({
    totalPrice: totalPrice
  });
});

app.listen(3000, () => {
  console.log('Food ordering API listening on port 3000');
});
